﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryApp
{
    public partial class Transactions : Form
    {
        public Transactions()
        {
            InitializeComponent();
        }

        private void Transactions_Load(object sender, EventArgs e)
        {
            LoadBorrowtable();
            Book.LoadDataIntoDataGridView(allBooksTbl);
        }

        private void txtBorrowerID_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoadBorrowtable()
        {
            using (SqlConnection con = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();

                string query = "SELECT BorrowerID, BookID, BorrowDate FROM Borrowers";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);


                TblBorrow.DataSource = dataTable;
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            string bookIdToReturn = ReturnID.Text;


            using (SqlConnection con = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();

                // Check if the book is borrowed
                SqlCommand checkBorrowedCmd = new SqlCommand("SELECT BorrowerID FROM Borrowers WHERE BookID = @BookID", con);
                checkBorrowedCmd.Parameters.AddWithValue("@BookID", bookIdToReturn);
                object borrowerIdObj = checkBorrowedCmd.ExecuteScalar();

                if (borrowerIdObj == null || borrowerIdObj == DBNull.Value)
                {
                    MessageBox.Show("This book is not currently borrowed.");
                    return;
                }


                // Remove the association with the borrower
                SqlCommand removeBorrowerCmd = new SqlCommand("DELETE FROM Borrowers WHERE BookID = @BookID", con);
                removeBorrowerCmd.Parameters.AddWithValue("@BookID", ReturnID.Text);
                removeBorrowerCmd.ExecuteNonQuery();

                // Update the Books table to mark the book as available
                SqlCommand updateBookCmd = new SqlCommand("UPDATE Books SET Status = 'Available' WHERE ID = @BookID", con);
                updateBookCmd.Parameters.AddWithValue("@BookID", bookIdToReturn);
                updateBookCmd.ExecuteNonQuery();

                con.Close();

                // Refresh DataGridView or perform any other necessary actions
                Book.LoadDataIntoDataGridView(allBooksTbl);
                LoadBorrowtable();

                MessageBox.Show("Book successfully returned to the library.");
                ClearBookDetails();
            }
        }

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            string borrowerId = txtBorrowerID.Text;
            string bookId = txtID.Text;
            DateTime borrowDate = DateTime.Now;

            using (SqlConnection con = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=LibrarySystem;Integrated Security=True"))
            {
                con.Open();

                // Check if the book is available
                SqlCommand checkAvailabilityCmd = new SqlCommand("SELECT Status FROM Books WHERE ID = @BookID", con);
                checkAvailabilityCmd.Parameters.AddWithValue("@BookID", bookId);
                object statusObj = checkAvailabilityCmd.ExecuteScalar();

                if (statusObj == null || statusObj == DBNull.Value)
                {
                    MessageBox.Show("This book doesn't exist in the library.");
                    return;
                }

                string bookStatus = (string)statusObj;

                if (bookStatus != "Available")
                {
                    MessageBox.Show("This book is not available for borrowing.");
                    return;
                }

                // Insert into Borrowers table
                SqlCommand borrowCmd = new SqlCommand("INSERT INTO Borrowers (BorrowerID, BookID, BorrowDate) VALUES (@BorrowerID, @BookID, @BorrowDate)", con);
                borrowCmd.Parameters.AddWithValue("@BorrowerID", borrowerId);
                borrowCmd.Parameters.AddWithValue("@BookID", bookId);
                borrowCmd.Parameters.AddWithValue("@BorrowDate", borrowDate);
                borrowCmd.ExecuteNonQuery();

                // Update book status to 'Borrowed'
                SqlCommand updateBookCmd = new SqlCommand("UPDATE Books SET Status = 'Borrowed' WHERE ID = @BookID", con);
                updateBookCmd.Parameters.AddWithValue("@BookID", bookId);
                updateBookCmd.ExecuteNonQuery();
                LoadBorrowtable();

                con.Close();

                // Refresh DataGridView or perform any other necessary actions
                Book.LoadDataIntoDataGridView(allBooksTbl);

                MessageBox.Show("Book successfully borrowed.");
                ClearBookDetails();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ClearBookDetails();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClearBookDetails();
        }

        private void ClearBookDetails()
        {
            txtID.Text = "";
            txtBorrowerID.Text = "";
            ReturnID.Text = "";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MainMenu menu = new MainMenu();
            this.Hide();
            menu.Show();

        }

        private void TblBorrow_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
