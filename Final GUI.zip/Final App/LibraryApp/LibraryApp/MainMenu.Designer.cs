﻿namespace LibraryApp
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnTrans;
            System.Windows.Forms.Button exit;
            this.label1 = new System.Windows.Forms.Label();
            this.btnBookMgmt = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            btnTrans = new System.Windows.Forms.Button();
            exit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 12F);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(156, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Library Management System";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnBookMgmt
            // 
            this.btnBookMgmt.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnBookMgmt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBookMgmt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBookMgmt.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 13F);
            this.btnBookMgmt.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBookMgmt.Location = new System.Drawing.Point(43, 189);
            this.btnBookMgmt.Name = "btnBookMgmt";
            this.btnBookMgmt.Size = new System.Drawing.Size(329, 62);
            this.btnBookMgmt.TabIndex = 1;
            this.btnBookMgmt.Text = "Book Management";
            this.btnBookMgmt.UseVisualStyleBackColor = false;
            this.btnBookMgmt.Click += new System.EventHandler(this.btnBookMgmt_Click);
            // 
            // btnTrans
            // 
            btnTrans.BackColor = System.Drawing.SystemColors.ActiveCaption;
            btnTrans.Cursor = System.Windows.Forms.Cursors.Hand;
            btnTrans.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnTrans.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 13F);
            btnTrans.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            btnTrans.Location = new System.Drawing.Point(43, 257);
            btnTrans.Name = "btnTrans";
            btnTrans.Size = new System.Drawing.Size(329, 66);
            btnTrans.TabIndex = 2;
            btnTrans.Text = "Transactions";
            btnTrans.UseVisualStyleBackColor = false;
            btnTrans.Click += new System.EventHandler(this.btnTrans_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(1, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(415, 125);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::LibraryApp.Properties.Resources._8074804;
            this.pictureBox1.Location = new System.Drawing.Point(20, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(99, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // exit
            // 
            exit.BackColor = System.Drawing.Color.Brown;
            exit.Cursor = System.Windows.Forms.Cursors.Hand;
            exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            exit.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 13F);
            exit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            exit.Location = new System.Drawing.Point(43, 410);
            exit.Name = "exit";
            exit.Size = new System.Drawing.Size(329, 56);
            exit.TabIndex = 4;
            exit.Text = "Exit";
            exit.UseVisualStyleBackColor = false;
            exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(417, 508);
            this.Controls.Add(exit);
            this.Controls.Add(btnTrans);
            this.Controls.Add(this.btnBookMgmt);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainMenu";
            this.Text = "MainMenu";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBookMgmt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}