﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryApp
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void btnBookMgmt_Click(object sender, EventArgs e)
        {
            BookMgmt bookwin = new BookMgmt();
            this.Hide();
            bookwin.Show();
            
        }

        private void btnTrans_Click(object sender, EventArgs e)
        {
            Transactions trans = new Transactions();
            this.Hide();
            trans.Show();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
